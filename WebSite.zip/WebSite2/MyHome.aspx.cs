﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class MyHome : System.Web.UI.Page
{
    private string connectionString = ConfigurationManager.ConnectionStrings["SQLConnectionString"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {
        if(!IsPostBack)
        {
            if (Session["UserName"] == null || Session["UserPwd"] == null)
            {
                Response.Write("<script>alert('请先登录！');window.location.href='Login.aspx';</script>");
            }
            else
            {
                Label2.Text = "当前用户名、密码：" + Session["UserName"].ToString() + "/" + Session["UserPwd"].ToString();
                Label3.Text = "当前系统时间：" + DateTime.Now.ToString();

                ListBMyClass.Items.Add(new ListItem("我所选修的课程"));

            }
        }
    }

    protected void btnLogout_Click(object sender, EventArgs e)
    {
        Session.Abandon();
        Response.Redirect("~/Login.aspx");
    }

    protected void btnSearchMyClass_Click(object sender, EventArgs e)
    {
        SqlConnection conn = new SqlConnection(connectionString);

        string cmdText = "SELECT * FROM STUDENT_CLASS WHERE USERID = '" + Session["UserName"].ToString() + "'";
        SqlCommand command = new SqlCommand(cmdText, conn);
        try
        {
            conn.Open();
            SqlDataReader dr = command.ExecuteReader();
            while (dr.Read())
            {
                ListBMyClass.Items.Add(new ListItem(dr["CLASSID"].ToString()));
            }
            dr.Close();
        }
        catch (SqlException sqlex)
        {
            //显示错误信息
            Response.Write(sqlex.Message + "<br />");
        }
        finally
        {
            //关闭数据库链接
            conn.Close();
        }
    }
}