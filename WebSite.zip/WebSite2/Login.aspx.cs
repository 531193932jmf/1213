﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Login : System.Web.UI.Page
{
    private string connectionString = ConfigurationManager.ConnectionStrings["SQLConnectionString1"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnLogin_Click(object sender, EventArgs e)
    {
        //检查是否为合法用户
        string userName = txtUser.Text.Trim();
        string userPwd = txtPassword.Text.Trim();
        if (userName == "")
        {
            warning.Text = "用户名不能为空！";
        }
        else if(userPwd == "")
        {
            warning.Text = "密码不能为空！";
        }
        else
        {
            SqlConnection conn = new SqlConnection(connectionString);

            string cmdText = "SELECT * FROM [user] WHERE UserName = '" + userName + "'" + "AND Password ='" + userPwd + "'";
            SqlCommand command = new SqlCommand(cmdText, conn);
            try
            {
                conn.Open();
                SqlDataReader dr = command.ExecuteReader();
                if (dr.Read())
                {   //是，创建session变量保存用户名和密码，重定向到MyHome.aspx

                    Session["UserName"] = userName;
                    Session["UserPwd"] = userPwd;

                    Response.Redirect("~/Home.aspx");
                }
                else    //否
                {
                    warning.Text = "请输入正确的用户名与密码！";
                }
                dr.Close();
            }
            catch (SqlException sqlex)
            {
                //显示错误信息
                Response.Write(sqlex.Message + "<br />");
            }
            finally
            {
                //关闭数据库链接
                conn.Close();
            }
        }
        
    }


}