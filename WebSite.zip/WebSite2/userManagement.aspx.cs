﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class userManagement : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            this.Panel1.Visible = false;
        }
    }

    protected void btnAdd_Click(object sender, EventArgs e)
    {
        //置Panel1为可见
        this.Panel1.Visible = true;
        //置“删除”按钮不可见
        this.btnDelete.Visible = false;

        //将各输入域置空。因为也许以前在编辑时已经为各域赋了值
        this.UserIDTextBox.ReadOnly = false;
        this.UserNameTextBox.Text = "";
        this.PhoneNumberTextBox.Text = "";
        this.UserTypeTextBox.Text = "";
        this.PasswordTextBox.Text = "";
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        //取得修改后的值
        String UserID = Request.Params["UserIDTextBox"].ToString();
        String UserName = Request.Params["UserNameTextBox"].ToString();
        String PhoneNumber = Request.Params["PhoneNumberTextBox"].ToString();
        String UserType = Request.Params["UserTypeTextBox"].ToString();
        String Password = Request.Params["PasswordTextBox"].ToString();

        //根据USERID域是否为只读来判断编辑状态
        //如果不只读（说明是“新增”状态）
        if (!this.UserIDTextBox.ReadOnly)
        {
            //置插入命令的参数
            System.Web.UI.WebControls.Parameter param =
               SqlDataSource1.InsertParameters["UserID"];
            param.DefaultValue = UserID;
            param = SqlDataSource1.InsertParameters["UserName"];
            param.DefaultValue = UserName;
            param = SqlDataSource1.InsertParameters["PhoneNumber"];
            param.DefaultValue = PhoneNumber;
            param = SqlDataSource1.InsertParameters["UserType"];
            param.DefaultValue = UserType;
            param = SqlDataSource1.InsertParameters["Password"];
            param.DefaultValue = Password;
            //调用SqlDataSource的插入事件，向数据库插入记录
            SqlDataSource1.Insert();
        }

        //如果只读（说明是“修改”状态）
        if (this.UserIDTextBox.ReadOnly)
        {
            //置修改命令的参数
            System.Web.UI.WebControls.Parameter param =
               SqlDataSource1.UpdateParameters["UserID"];
            param.DefaultValue = UserID;
            param = SqlDataSource1.UpdateParameters["UserName"];
            param.DefaultValue = UserName;
            param = SqlDataSource1.UpdateParameters["PhoneNumber"];
            param.DefaultValue = PhoneNumber;
            param = SqlDataSource1.UpdateParameters["UserType"];
            param.DefaultValue = UserType;
            param = SqlDataSource1.UpdateParameters["Password"];
            param.DefaultValue = Password;
            //调用SqlDataSource的修改事件，修改数据库中的记录
            SqlDataSource1.Update();
        }

        //修改完成，将Panel1置为不可见
        this.Panel1.Visible = false;
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        //取消操作，将Panel1置为不可见
        this.Panel1.Visible = false;
    }
    protected void btnDelete_Click(object sender, EventArgs e)
    {
        //置删除命令的参数
        String UserID = Request.Params["UserIDTextBox"].ToString();
        System.Web.UI.WebControls.Parameter param =
            SqlDataSource1.DeleteParameters["UserID"];
        param.DefaultValue = UserID;
        //调用SqlDataSource的删除事件，删除数据库中的记录
        SqlDataSource1.Delete();
        //删除完成，将Panel1置为不可见
        this.Panel1.Visible = false;
    }

    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        //如果是数据行则进行处理
        /*if (e.Row.RowType == DataControlRowType.DataRow)
        {
            //取左数第4个(从0开始计数)单元格(生日)的数据
            TableCell cell = e.Row.Cells[4];
            string s = cell.Text;
            //删除空格以后的部分
            int i = s.IndexOf(' ');
            int j = s.Length;
            if (i >= 0)
                s = s.Remove(i, j - i);
            //将修改后的文本写回单元格
            cell.Text = s;
        }*/
    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        //置Panel1为可见
        this.Panel1.Visible = true;
        //置“删除”按钮可见。因为也许在“新增”时已经将其置为不可见。
        this.btnDelete.Visible = true;

        //从GridView1的当前行取原值
        GridViewRow row = GridView1.SelectedRow;
        String UserID = row.Cells[0].Text;
        String UserName = row.Cells[1].Text;
        String PhoneNumber = row.Cells[2].Text;
        String UserType = row.Cells[3].Text;
        String Password = row.Cells[4].Text;
        //对可能为空的字段需要进行特殊处理，如下：
        /*String SEX = row.Cells[3].Text;
        if (SEX == "&nbsp;") SEX = "";
        String BIRTHDAY = row.Cells[4].Text;
        if (BIRTHDAY == "&nbsp;") BIRTHDAY = "";
        String REGTIME = row.Cells[5].Text;
        if (REGTIME == "&nbsp;") REGTIME = "";
        String SPECIALTY = row.Cells[6].Text;
        if (SPECIALTY == "&nbsp;") SPECIALTY = "";
        String REMARK = row.Cells[7].Text;
        if (REMARK == "&nbsp;") REMARK = "";*/

        //为修改部分置初值
        //USERID为主键字段，不允许修改
        this.UserIDTextBox.ReadOnly = true;
        this.UserIDTextBox.Text = UserID;
        this.UserNameTextBox.Text = UserName;
        this.PhoneNumberTextBox.Text = PhoneNumber;
        this.UserTypeTextBox.Text = UserType;
        this.PasswordTextBox.Text = Password;
    }
}