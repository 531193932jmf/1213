﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class systemManagement : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //string ct = System.DateTime.Now.ToString("G");
        //currentTime.Text = ct;
    }
}