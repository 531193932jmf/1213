#!/usr/bin/env python
# coding=UTF-8  
from __future__ import absolute_import, division, print_function, unicode_literals
import os
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'
from tensorflow import feature_column
from tensorflow.keras import layers
from sklearn.model_selection import train_test_split
from sklearn.metrics import f1_score, precision_score, recall_score
import matplotlib
matplotlib.use('TkAgg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import tensorflow as tf
from tensorflow import feature_column
from tensorflow.keras import layers
from sklearn.model_selection import train_test_split
from tensorflow.keras.callbacks import EarlyStopping
early_stopping = EarlyStopping(monitor='val_loss', patience=2)
os.environ["CUDA_VISIBLE_DEVICES"] = '0'
#use GPU with ID=0
print(tf.test.is_gpu_available())
TRAIN_SPLIT = 40000

#CSV_FILE_PATH = 'Friday-WorkingHours-Afternoon-DDos.pcap_ISCX.csv'
#df=pd.read_csv("Friday-WorkingHours-Afternoon-DDos.pcap_ISCX.csv",header=0,low_memory=False)
#df[" Label"]
#这样就可以了

CSV_FILE_PATH = 'binary_classification.csv'
df = pd.read_csv(CSV_FILE_PATH)
print(len(df))

#Object类型转换为离散数值（Label列）
df['Label'] = pd.Categorical(df['Label'])
df['Label'] = df['Label'].cat.codes
#修改数据类型

print("df[label]",df['Label'].head(50))

columns_counts = df.shape[1]                           #获取列数
for i in range(columns_counts):
  if(df.iloc[:,i].dtypes) != 'float64':
    df.iloc[:, i] = df.iloc[:,i].astype(float)

#选取11个特征和Label
features_considered = ['Bwd_Packet_Length_Min','Subflow_Fwd_Bytes','Total_Length_of_Fwd_Packets','Fwd_Packet_Length_Mean','Bwd_Packet_Length_Std','Flow_Duration','Flow_IAT_Std','Init_Win_bytes_forward','Bwd_Packets/s',
                 'PSH_Flag_Count','Average_Packet_Size']
features = df[features_considered]
data_result = df['Label']
#标准化
dataset = features.values
feature_mean = dataset.mean(axis=0)
feature_std = dataset.std(axis=0)
dataset = (dataset-feature_mean)/feature_std
dataset = pd.DataFrame(dataset,columns=features_considered)
dataset.insert(0,'Label',data_result)
dataset = dataset.values
#返回时间窗,根据给定步长对过去的观察进行采样  history_size为过去信息窗口的大小，target_size为模型需要预测的未来时间
def multivariate_data(dataset, target, start_index, end_index, history_size,
                      target_size, step, single_step=False):
  data = []
  labels = []

  start_index = start_index + history_size
  if end_index is None:
    end_index = len(dataset) - target_size                                      #如果未指定end_index,则设置最后一个训练点

  for i in range(start_index, end_index):
    indices = range(i-history_size, i, step)
    data.append(dataset[indices])

    if single_step:
      labels.append(target[i+target_size])                                      #仅仅预测未来的单个点
    else:
      labels.append(target[i:i+target_size])

  return np.array(data), np.array(labels)


past_history = 10000
future_target = 256
STEP = 6

x_train_single, y_train_single = multivariate_data(dataset, dataset[:, 0], 0,
                                                   TRAIN_SPLIT, past_history,
                                                   future_target, STEP,
                                                   single_step=False)            #dataset[:,1]取最后一列的所有值


x_val_single, y_val_single = multivariate_data(dataset, dataset[:, 0],
                                               TRAIN_SPLIT, None, past_history,
                                               future_target, STEP,
                                               single_step=False)


#训练集、验证集
BATCH_SIZE = 256
BUFFER_SIZE = 10000
train_data_single = tf.data.Dataset.from_tensor_slices((x_train_single, y_train_single))
train_data_single = train_data_single.cache().shuffle(BUFFER_SIZE).batch(BATCH_SIZE).repeat()
val_data_single = tf.data.Dataset.from_tensor_slices((x_val_single, y_val_single))
val_data_single = val_data_single.batch(BATCH_SIZE).repeat()
#创建模型,单点模型。


model = tf.keras.Sequential([
    #layers.LSTM(64,return_sequences=False,input_shape=x_train_single.shape[-2:]),
    #layers.LSTM(32,kernel_initializer='lecun_uniform'),
    #layers.Bidirectional(tf.keras.layers.LSTM(32,  return_sequences=True,input_shape=x_train_single.shape[-2:])),
    #layers.Bidirectional(tf.keras.layers.LSTM(8,kernel_initializer='lecun_uniform')),
    #不用它了，太烦了，但学一下。
    layers.LSTM(32,input_shape=x_train_single.shape[-2:],return_sequences=True),#注意输入维度
    layers.LSTM(16,activation='relu'),
    #一会试一下 预测。像天气预测一样。那么不要再有激活函数。
    layers.Dropout(0.2),
    layers.Dense(128),#这个不是batch_size，而是future_target，值一样而已。
    layers.Dense(64, activation='relu'),
    layers.Dropout(0.2),
    layers.Dense(32, activation='relu'),
    layers.Dropout(0.2),
    layers.Dense(16, activation='relu'),
    layers.Dropout(0.2),
    layers.Dense(4, activation='softmax')
])


print(model.summary())
# loss = 'sparse_categorical_crossentropy'
# optimizer = tf.keras.optimizers.SGD(0.1)
model.compile(optimizer=tf.keras.optimizers.RMSprop(clipvalue=0.1),

              loss='sparse_categorical_crossentropy',
              metrics=['accuracy'],)
log_dir = "graph/log_fit/7"
tensorboard_callback = tf.keras.callbacks.TensorBoard(log_dir=log_dir, histogram_freq=1)




history=model.fit(train_data_single,epochs=10,steps_per_epoch=2000,batch_size=256)


#batch_size=256,
#使用这种是数据被打乱过后的,但同样效果应该,因为本身就乱。这样可设定steps_per_epoch(也许不这样也可)
#validation_data=val_data_single,#如果有这个，需要repeat(),但不用evaluate了，因为其中history中。
#validation_steps=50,#在每个时期结束时评估损失和任何模型度量的数据。模型将不会在此数据上进行训练。
#,early_stopping]

print(model.output_shape)
print(model.summary())
#x,y或直接  训练集不可以
#model.fit(train_data_single, epochs=50, batch_size=256,callbacks=[tensorboard_callback])
#When providing an infinite dataset, you must specify the
# number of steps to run (if you did not intend to create an infinite dataset,
# make sure to not call `repeat()` on the dataset).
'''
提供无限数据集时，必须指定要运行的步骤数(如果不打算创建无限数据集，请确保不要在数据集上调用“repeat()”
'''

#print("model_evaluate......",model.evaluate(val_data_single))
# 其数据是从tfrecords中取出的。TFRecord 文件包含一系列记录。该文件只能按顺序读取


print(model.summary())
for x,y in val_data_single.take(3):#拿出来三个 batch_size
    print("model.predict(x).shape==================",model.predict(x).shape)
    #第一个256为batch_size,
    print("x:\n",x[0][:, 1].numpy(), "y:\n",y[0].numpy(),"pre:\n",model.predict(x)[0])
    result=model.predict(x)[0]
    print("result:",np.argmax(result))
#历史，真实，预测图
def multi_step_plot(history,true_future,prediction):
    plt.figure(figsize=(12,6))
    num_in=create_time_steps(len(history))
    num_out=len(true_future)

    plt.plot(num_in,np.array(history[:,1]),label='History')

    plt.plot(np.arange(num_out)/STEP,np.array(true_future),'bo',label='True Future')
    if prediction.any():
        plt.plot(np.arange(num_out)/STEP,np.array(prediction),'ro',label='Predicted future')
    plt.legend(loc='upper left')
    plt.show()
#建立时间序列，为了展示
def create_time_steps(length):
#建立时间序列，为了展示
    time_steps=[]
    for i in range(-length,0,1):
        time_steps.append(i)
    return time_steps
#普通的图
def show_plot(plot_data,delta,title):#delta为未来值
    labels=['History','Treu Future','Model prediction']
    marker=['.-','rx','go']
    time_steps=create_time_steps(plot_data[0].shape[0])
    if delta:
        future=delta
    else:
        future=0

    plt.title(title)
    for i,x in enumerate(plot_data):
        if i:
            plt.plot(future,plot_data[i],marker[i],markersize=10,label=labels)
        else:
            plt.plot(time_steps,plot_data[i].flatten(), marker[i],  label=labels)
    plt.legend()
    plt.xlim([time_steps[0],(future+5)*2])
    plt.xlabel('Timer-Step')
    return plt
model.save('LSTM_Model')
def result_csv(val_data_single):
    j=1;
    result_df=pd.DataFrame(columns=["x","y","pre"])
    for x, y in val_data_single.take(3):  # 拿出来三个 batch_size
        print("model.predict(x).shape==================", model.predict(x).shape)
        # 第一个256为batch_size,但也不一定，看看批量处理的x是多大。
        print("single input size",len(x[0]),"index:", j, "\ny:", y[0].numpy(), "\npre:", model.predict(x)[0])
        print(x.shape)
        result = model.predict(x)[0]#得到的是4个的概率
        print("result:", np.argmax(result))
        sum=model.predict(x).shape
        sum=sum[0]
        if sum>0:
            for i in range(sum):
                result=model.predict(x)[i]
                result=np.argmax(result)
                result_df.loc[j, :] = [j, y[i].numpy(),result]
                j+=1
    result_df.to_csv("result_1.csv",header=False,index=False)
#result_csv(val_data_single=val_data_single)
reconstructed_model = tf.keras.models.load_model('LSTM_Model')
